-- --------------------------------------------------------
-- Host:                         192.168.178.192
-- Server versie:                10.11.2-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Versie:              11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Databasestructuur van voorthuiscustomersales wordt geschreven
CREATE DATABASE IF NOT EXISTS `voorthuiscustomersales` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `voorthuiscustomersales`;

-- Structuur van  tabel voorthuiscustomersales.tb100_customer wordt geschreven
CREATE TABLE IF NOT EXISTS `tb100_customer` (
  `Id` int(11) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Postcode` varchar(6) DEFAULT NULL,
  `HouseNumber` varchar(7) DEFAULT NULL,
  `HouseNumberTvo` varchar(15) DEFAULT NULL,
  `Street` varchar(50) DEFAULT NULL,
  `City` varchar(50) DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb100_customer: ~0 rows (ongeveer)
/*!40000 ALTER TABLE `tb100_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb100_customer` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb110_address wordt geschreven
CREATE TABLE IF NOT EXISTS `tb110_address` (
  `ip` varchar(15) NOT NULL DEFAULT '',
  `email` varchar(70) DEFAULT NULL,
  `zipcode` varchar(6) NOT NULL DEFAULT '',
  `hsNumber` varchar(10) NOT NULL DEFAULT '',
  `hsNumTvo` varchar(10) NOT NULL DEFAULT '',
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ip`) USING BTREE,
  KEY `tb110_address_idx` (`ip`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb110_address: ~1 rows (ongeveer)
/*!40000 ALTER TABLE `tb110_address` DISABLE KEYS */;
REPLACE INTO `tb110_address` (`ip`, `email`, `zipcode`, `hsNumber`, `hsNumTvo`, `Timestamp`) VALUES
	('077.173.243.036', 'roland.labruyere@gmail.com', '1831EP', '5', '', '2026-04-10 11:41:16:491');
/*!40000 ALTER TABLE `tb110_address` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb200_power_trafo_config wordt geschreven
CREATE TABLE IF NOT EXISTS `tb200_power_trafo_config` (
  `ip` varchar(15) NOT NULL DEFAULT '0',
  `trafoNum` varchar(25) NOT NULL DEFAULT '0',
  `isClosed` tinyint(4) NOT NULL DEFAULT 0,
  `secundary` tinyint(4) NOT NULL DEFAULT 0,
  `volts` int(11) NOT NULL DEFAULT 0,
  `milliAmps` int(11) NOT NULL DEFAULT 0,
  `centerTap` tinyint(4) NOT NULL DEFAULT 0,
  `tapFiftyVolt` tinyint(4) NOT NULL DEFAULT 0,
  `filamentFiveAmps` decimal(4,2) NOT NULL DEFAULT 0.00,
  `filamentSixAmps` decimal(4,2) NOT NULL DEFAULT 0.00,
  `filamentTwelveAmps` decimal(4,2) NOT NULL DEFAULT 0.00,
  `filamentCenterTap` tinyint(4) NOT NULL DEFAULT 0,
  `timestamp` varchar(25) NOT NULL,
  PRIMARY KEY (`ip`,`trafoNum`) USING BTREE,
  KEY `TrafoNum` (`trafoNum`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb200_power_trafo_config: ~15 rows (ongeveer)
/*!40000 ALTER TABLE `tb200_power_trafo_config` DISABLE KEYS */;
REPLACE INTO `tb200_power_trafo_config` (`ip`, `trafoNum`, `isClosed`, `secundary`, `volts`, `milliAmps`, `centerTap`, `tapFiftyVolt`, `filamentFiveAmps`, `filamentSixAmps`, `filamentTwelveAmps`, `filamentCenterTap`, `timestamp`) VALUES
	('077.173.243.036', '20260500001', 1, 1, 400, 200, 0, 0, 0.00, 0.00, 0.00, 0, '2026-05-01 13:34:14:116'),
	('077.173.243.036', '20260500002', 1, 1, 400, 200, 0, 0, 0.00, 0.00, 0.00, 0, '2026-05-01 13:35:23:132'),
	('077.173.243.036', '20260500003', 1, 1, 400, 200, 0, 0, 0.00, 0.00, 0.00, 0, '2026-05-01 13:36:35:001'),
	('077.173.243.036', '20260500004', 1, 1, 400, 200, 0, 0, 0.00, 0.00, 0.00, 0, '2026-05-01 13:37:56:095'),
	('077.173.243.036', '20260500005', 1, 1, 400, 200, 0, 0, 0.00, 0.00, 0.00, 0, '2026-05-01 13:38:22:751'),
	('077.173.243.036', '20260500006', 1, 1, 400, 200, 0, 0, 0.00, 0.00, 0.00, 0, '2026-05-01 13:39:48:610'),
	('077.173.243.036', '20260500007', 1, 1, 435, 275, 0, 0, 3.50, 2.50, 0.00, 1, '2026-05-01 13:42:13:876'),
	('077.173.243.036', '20260500008', 1, 1, 400, 200, 0, 0, 0.00, 0.00, 0.00, 0, '2026-05-01 13:45:52:517'),
	('077.173.243.036', '20260500009', 1, 1, 400, 200, 0, 0, 0.00, 0.00, 0.00, 0, '2026-05-01 13:46:17:282'),
	('077.173.243.036', '20260500010', 1, 1, 400, 200, 0, 0, 0.00, 0.00, 0.00, 0, '2026-05-01 13:52:19:595'),
	('077.173.243.036', '20260500011', 1, 1, 400, 200, 0, 0, 0.00, 0.00, 0.00, 0, '2026-05-01 13:53:42:063'),
	('077.173.243.036', '20260500012', 1, 1, 400, 200, 0, 0, 0.00, 0.00, 0.00, 0, '2026-05-01 13:57:55:844'),
	('077.173.243.036', '20260500013', 1, 1, 400, 200, 0, 0, 0.00, 0.00, 0.00, 0, '2026-05-01 13:58:30:485'),
	('077.173.243.036', '20260500014', 1, 1, 400, 200, 0, 0, 0.00, 0.00, 0.00, 0, '2026-05-01 14:00:06:766'),
	('077.173.243.036', '20260500015', 1, 1, 400, 200, 0, 0, 0.00, 0.00, 0.00, 0, '2026-05-01 14:01:26:922');
/*!40000 ALTER TABLE `tb200_power_trafo_config` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb210_power_trafo_calcspecs wordt geschreven
CREATE TABLE IF NOT EXISTS `tb210_power_trafo_calcspecs` (
  `ip` varchar(15) NOT NULL,
  `trafonum` varchar(25) NOT NULL,
  `isClosed` tinyint(4) DEFAULT NULL,
  `isOrdered` tinyint(4) DEFAULT NULL,
  `hasDownloadedSchematic` tinyint(4) DEFAULT NULL,
  `primaryVA` varchar(25) DEFAULT NULL,
  `primaryAmps` varchar(25) DEFAULT NULL,
  `coreArea` varchar(25) DEFAULT NULL,
  `turnsPerVolt` varchar(25) DEFAULT NULL,
  `primWireSize` varchar(25) DEFAULT NULL,
  `primaryTurns` varchar(25) DEFAULT NULL,
  `secundaryTurns` varchar(25) DEFAULT NULL,
  `fiftyVoltTapTurns` varchar(25) DEFAULT NULL,
  `secCenterTapTurns` varchar(25) DEFAULT NULL,
  `secWireSize` varchar(25) DEFAULT NULL,
  `filFiveTurns` varchar(25) DEFAULT NULL,
  `filFiveCtTurns` varchar(25) DEFAULT NULL,
  `filFiveWireSize` varchar(25) DEFAULT NULL,
  `filSixTurns` varchar(25) DEFAULT NULL,
  `filSixCtTurns` varchar(25) DEFAULT NULL,
  `filSixWireSize` varchar(25) DEFAULT NULL,
  `filTwelveTurns` varchar(25) DEFAULT NULL,
  `filTwelveCtTurns` varchar(25) DEFAULT NULL,
  `filTwelveWireSize` varchar(25) DEFAULT NULL,
  `primTurnArea` varchar(25) DEFAULT NULL,
  `secTurnArea` varchar(25) DEFAULT NULL,
  `fiveVoltTurnArea` varchar(25) DEFAULT NULL,
  `sixVoltTurnArea` varchar(25) DEFAULT NULL,
  `twelveVoltTurnArea` varchar(25) DEFAULT NULL,
  `totalTurnArea` varchar(25) DEFAULT NULL,
  `sizeEiSheets` varchar(25) DEFAULT NULL,
  `timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ip`,`trafonum`) USING BTREE,
  KEY `trafonum` (`trafonum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb210_power_trafo_calcspecs: ~15 rows (ongeveer)
/*!40000 ALTER TABLE `tb210_power_trafo_calcspecs` DISABLE KEYS */;
REPLACE INTO `tb210_power_trafo_calcspecs` (`ip`, `trafonum`, `isClosed`, `isOrdered`, `hasDownloadedSchematic`, `primaryVA`, `primaryAmps`, `coreArea`, `turnsPerVolt`, `primWireSize`, `primaryTurns`, `secundaryTurns`, `fiftyVoltTapTurns`, `secCenterTapTurns`, `secWireSize`, `filFiveTurns`, `filFiveCtTurns`, `filFiveWireSize`, `filSixTurns`, `filSixCtTurns`, `filSixWireSize`, `filTwelveTurns`, `filTwelveCtTurns`, `filTwelveWireSize`, `primTurnArea`, `secTurnArea`, `fiveVoltTurnArea`, `sixVoltTurnArea`, `twelveVoltTurnArea`, `totalTurnArea`, `sizeEiSheets`, `timestamp`) VALUES
	('077.173.243.036', '20260500001', 0, 0, 0, '89', '0,38', '10,84', '4,61', '0,20', '1084', '1845', '0', '0', '0,15', '0', '0', '0.00', '0', '0', '0.00', '0', '0', '0.00', '1,73', '1,66', '0,00', '0,00', '0,00', '3,39', 'EI-66', '2026-05-01 13:34:14:148'),
	('077.173.243.036', '20260500002', 0, 0, 0, '89', '0,38', '10,84', '4,61', '0,20', '1084', '1845', '0', '0', '0,15', '0', '0', '0.00', '0', '0', '0.00', '0', '0', '0.00', '1,73', '1,66', '0,00', '0,00', '0,00', '3,39', 'EI-66', '2026-05-01 13:35:23:148'),
	('077.173.243.036', '20260500003', 0, 0, 0, '89', '0,38', '10,84', '4,61', '0,20', '1084', '1845', '0', '0', '0,15', '0', '0', '0.00', '0', '0', '0.00', '0', '0', '0.00', '1,73', '1,66', '0,00', '0,00', '0,00', '3,39', 'EI-66', '2026-05-01 13:36:35:001'),
	('077.173.243.036', '20260500004', 0, 0, 0, '89', '0,38', '10,84', '4,61', '0,20', '1084', '1845', '0', '0', '0,15', '0', '0', '0.00', '0', '0', '0.00', '0', '0', '0.00', '1,73', '1,66', '0,00', '0,00', '0,00', '3,39', 'EI-66', '2026-05-01 13:37:56:110'),
	('077.173.243.036', '20260500005', 0, 0, 0, '89', '0,38', '10,84', '4,61', '0,20', '1084', '1845', '0', '0', '0,15', '0', '0', '0.00', '0', '0', '0.00', '0', '0', '0.00', '1,73', '1,66', '0,00', '0,00', '0,00', '3,39', 'EI-66', '2026-05-01 13:38:22:767'),
	('077.173.243.036', '20260500006', 0, 0, 0, '89', '0,38', '10,84', '4,61', '0,20', '1084', '1845', '0', '0', '0,15', '0', '0', '0.00', '0', '0', '0.00', '0', '0', '0.00', '1,73', '1,66', '0,00', '0,00', '0,00', '3,39', 'EI-66', '2026-05-01 13:39:48:626'),
	('077.173.243.036', '20260500007', 0, 0, 0, '170', '0,72', '14,99', '3,34', '0,30', '784', '1451', '0', '0', '0,20', '17', '8', '0,65', '21', '11', '0,55', '0', '0', '0.00', '2,82', '2,32', '0,28', '0,25', '0,00', '5,68', 'EI-84', '2026-05-01 13:42:13:907'),
	('077.173.243.036', '20260500008', 0, 0, 0, '89', '0,38', '10,84', '4,61', '0,20', '1084', '1845', '0', '0', '0,15', '0', '0', '0.00', '0', '0', '0.00', '0', '0', '0.00', '1,73', '1,66', '0,00', '0,00', '0,00', '3,39', 'EI-66', '2026-05-01 13:45:52:548'),
	('077.173.243.036', '20260500009', 0, 0, 0, '89', '0,38', '10,84', '4,61', '0,20', '1084', '1845', '0', '0', '0,15', '0', '0', '0.00', '0', '0', '0.00', '0', '0', '0.00', '1,73', '1,66', '0,00', '0,00', '0,00', '3,39', 'EI-66', '2026-05-01 13:46:17:282'),
	('077.173.243.036', '20260500010', 0, 0, 0, '89', '0,38', '10,84', '4,61', '0,20', '1084', '1845', '0', '0', '0,15', '0', '0', '0.00', '0', '0', '0.00', '0', '0', '0.00', '1,73', '1,66', '0,00', '0,00', '0,00', '3,39', 'EI-66', '2026-05-01 13:52:19:626'),
	('077.173.243.036', '20260500011', 0, 0, 0, '89', '0,38', '10,84', '4,61', '0,20', '1084', '1845', '0', '0', '0,15', '0', '0', '0.00', '0', '0', '0.00', '0', '0', '0.00', '1,73', '1,66', '0,00', '0,00', '0,00', '3,39', 'EI-66', '2026-05-01 13:53:42:063'),
	('077.173.243.036', '20260500012', 0, 0, 0, '89', '0,38', '10,84', '4,61', '0,20', '1084', '1845', '0', '0', '0,15', '0', '0', '0.00', '0', '0', '0.00', '0', '0', '0.00', '1,73', '1,66', '0,00', '0,00', '0,00', '3,39', 'EI-66', '2026-05-01 13:57:55:844'),
	('077.173.243.036', '20260500013', 0, 0, 0, '89', '0,38', '10,84', '4,61', '0,20', '1084', '1845', '0', '0', '0,15', '0', '0', '0.00', '0', '0', '0.00', '0', '0', '0.00', '1,73', '1,66', '0,00', '0,00', '0,00', '3,39', 'EI-66', '2026-05-01 13:58:30:501'),
	('077.173.243.036', '20260500014', 0, 0, 0, '89', '0,38', '10,84', '4,61', '0,20', '1084', '1845', '0', '0', '0,15', '0', '0', '0.00', '0', '0', '0.00', '0', '0', '0.00', '1,73', '1,66', '0,00', '0,00', '0,00', '3,39', 'EI-66', '2026-05-01 14:00:06:782'),
	('077.173.243.036', '20260500015', 0, 0, 0, '89', '0,38', '10,84', '4,61', '0,20', '1084', '1845', '0', '0', '0,15', '0', '0', '0.00', '0', '0', '0.00', '0', '0', '0.00', '1,73', '1,66', '0,00', '0,00', '0,00', '3,39', 'EI-66', '2026-05-01 14:01:26:938');
/*!40000 ALTER TABLE `tb210_power_trafo_calcspecs` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb300_shoppingcart wordt geschreven
CREATE TABLE IF NOT EXISTS `tb300_shoppingcart` (
  `ClientId` varchar(36) NOT NULL,
  `GotItems` tinyint(1) DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ClientId`),
  KEY `tb300_shoppingcart_idx` (`ClientId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb300_shoppingcart: ~0 rows (ongeveer)
/*!40000 ALTER TABLE `tb300_shoppingcart` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb300_shoppingcart` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb310_shoppingcartitems wordt geschreven
CREATE TABLE IF NOT EXISTS `tb310_shoppingcartitems` (
  `ClientId` varchar(36) NOT NULL,
  `OrderRow` int(11) NOT NULL DEFAULT 0,
  `Description` varchar(50) NOT NULL,
  `IndexNr` int(11) NOT NULL,
  `itemsOrdered` int(11) DEFAULT NULL,
  `Price` float DEFAULT NULL,
  `totalItemPrice` float DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ClientId`,`OrderRow`) USING BTREE,
  KEY `tb310_shoppingcartitems_idx` (`ClientId`,`OrderRow`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb310_shoppingcartitems: ~0 rows (ongeveer)
/*!40000 ALTER TABLE `tb310_shoppingcartitems` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb310_shoppingcartitems` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb900_session_settings wordt geschreven
CREATE TABLE IF NOT EXISTS `tb900_session_settings` (
  `ip` varchar(15) NOT NULL,
  `SessionActive` tinyint(1) NOT NULL DEFAULT 0,
  `Timestamp` varchar(25) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ip`),
  KEY `Index 1` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb900_session_settings: ~1 rows (ongeveer)
/*!40000 ALTER TABLE `tb900_session_settings` DISABLE KEYS */;
REPLACE INTO `tb900_session_settings` (`ip`, `SessionActive`, `Timestamp`) VALUES
	('077.173.243.036', 1, '2026-05-01 14:03:06:954');
/*!40000 ALTER TABLE `tb900_session_settings` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb910_temp_trafo_settings wordt geschreven
CREATE TABLE IF NOT EXISTS `tb910_temp_trafo_settings` (
  `Ip` varchar(15) NOT NULL,
  `Part` int(11) NOT NULL DEFAULT 0,
  `TrafoType` varchar(50) DEFAULT NULL,
  `CommonValues` varchar(500) DEFAULT NULL,
  `TimeStamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Ip`,`Part`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb910_temp_trafo_settings: ~2 rows (ongeveer)
/*!40000 ALTER TABLE `tb910_temp_trafo_settings` DISABLE KEYS */;
REPLACE INTO `tb910_temp_trafo_settings` (`Ip`, `Part`, `TrafoType`, `CommonValues`, `TimeStamp`) VALUES
	('077.173.243.036', 1, 'powertrafo', '1', '2026-05-01 14:01:21:485'),
	('077.173.243.036', 2, 'powertrafo', 'volts=400-milliAmps=200-', '2026-05-01 14:01:26:907');
/*!40000 ALTER TABLE `tb910_temp_trafo_settings` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb920_customer_settings wordt geschreven
CREATE TABLE IF NOT EXISTS `tb920_customer_settings` (
  `Ip` varchar(15) NOT NULL DEFAULT '',
  `PermissionStoreAddress` tinyint(4) DEFAULT NULL,
  `PermissionStorePaymentStats` tinyint(4) DEFAULT NULL,
  `AgreeShopConditions` tinyint(4) DEFAULT NULL,
  `ShowInteractiveHelp` tinyint(4) DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Ip`) USING BTREE,
  KEY `tb920_idx` (`Ip`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb920_customer_settings: ~1 rows (ongeveer)
/*!40000 ALTER TABLE `tb920_customer_settings` DISABLE KEYS */;
REPLACE INTO `tb920_customer_settings` (`Ip`, `PermissionStoreAddress`, `PermissionStorePaymentStats`, `AgreeShopConditions`, `ShowInteractiveHelp`, `Timestamp`) VALUES
	('077.173.243.036', 1, 1, 1, 1, '2026-04-10 11:41:16:505');
/*!40000 ALTER TABLE `tb920_customer_settings` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb930_grid_settings_per_ip wordt geschreven
CREATE TABLE IF NOT EXISTS `tb930_grid_settings_per_ip` (
  `Ip` varchar(15) NOT NULL DEFAULT '0',
  `VoltageElectraGrid` int(11) DEFAULT NULL,
  `FreqElectraGrid` int(11) DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Ip`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb930_grid_settings_per_ip: ~2 rows (ongeveer)
/*!40000 ALTER TABLE `tb930_grid_settings_per_ip` DISABLE KEYS */;
REPLACE INTO `tb930_grid_settings_per_ip` (`Ip`, `VoltageElectraGrid`, `FreqElectraGrid`, `Timestamp`) VALUES
	('077.173.243.036', 235, 50, '2026-04-10 11:41:16:479'),
	('localhost', 230, 50, '2026-03-01 00:00:00:000');
/*!40000 ALTER TABLE `tb930_grid_settings_per_ip` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb990_paper_trail wordt geschreven
CREATE TABLE IF NOT EXISTS `tb990_paper_trail` (
  `Ip` varchar(15) NOT NULL,
  `itemNumber` varchar(25) NOT NULL,
  `docName` varchar(20) NOT NULL,
  `fullPath` varchar(500) DEFAULT NULL,
  `timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Ip`,`itemNumber`,`docName`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb990_paper_trail: ~23 rows (ongeveer)
/*!40000 ALTER TABLE `tb990_paper_trail` DISABLE KEYS */;
REPLACE INTO `tb990_paper_trail` (`Ip`, `itemNumber`, `docName`, `fullPath`, `timestamp`) VALUES
	('077.173.243.036', '20260500001', 'wikkelschema', 'C:\\voorthuis\\templates\\download\\wikkelschema_20260500001.pdf', '2026-05-01 13:34:22:398'),
	('077.173.243.036', '20260500002', 'wikkelschema', 'C:\\voorthuis\\templates\\download\\wikkelschema_20260500002.pdf', '2026-05-01 13:35:31:382'),
	('077.173.243.036', '20260500003', 'wikkelschema', 'C:\\voorthuis\\templates\\download\\wikkelschema_20260500003.pdf', '2026-05-01 13:36:41:298'),
	('077.173.243.036', '20260500004', 'wikkelschema', 'C:\\voorthuis\\templates\\download\\wikkelschema_20260500004.pdf', '2026-05-01 13:38:02:267'),
	('077.173.243.036', '20260500005', 'wikkelschema', 'C:\\voorthuis\\templates\\download\\wikkelschema_20260500005.pdf', '2026-05-01 13:38:28:220'),
	('077.173.243.036', '20260500006', 'wikkelschema', 'C:\\voorthuis\\templates\\download\\wikkelschema_20260500006.pdf', '2026-05-01 13:39:55:142'),
	('077.173.243.036', '20260500007', 'materiaalLijst', 'C:\\voorthuis\\templates\\download\\materiaalLijst_20260500007.pdf', '2026-05-01 13:42:21:392'),
	('077.173.243.036', '20260500007', 'wikkelschema', 'C:\\voorthuis\\templates\\download\\wikkelschema_20260500007.pdf', '2026-05-01 13:42:29:908'),
	('077.173.243.036', '20260500008', 'materiaalLijst', 'C:\\voorthuis\\templates\\download\\materiaalLijst_20260500008.pdf', '2026-05-01 13:46:00:251'),
	('077.173.243.036', '20260500009', 'materiaalLijst', 'C:\\voorthuis\\templates\\download\\materiaalLijst_20260500009.pdf', '2026-05-01 13:46:23:376'),
	('077.173.243.036', '20260500009', 'wikkelschema', 'C:\\voorthuis\\templates\\download\\wikkelschema_20260500009.pdf', '2026-05-01 13:46:30:266'),
	('077.173.243.036', '20260500010', 'materiaalLijst', 'C:\\voorthuis\\templates\\download\\materiaalLijst_20260500010.pdf', '2026-05-01 13:52:25:344'),
	('077.173.243.036', '20260500010', 'wikkelschema', 'C:\\voorthuis\\templates\\download\\wikkelschema_20260500010.pdf', '2026-05-01 13:52:29:142'),
	('077.173.243.036', '20260500011', 'materiaalLijst', 'C:\\voorthuis\\templates\\download\\materiaalLijst_20260500011.pdf', '2026-05-01 13:54:06:688'),
	('077.173.243.036', '20260500011', 'wikkelschema', 'C:\\voorthuis\\templates\\download\\wikkelschema_20260500011.pdf', '2026-05-01 13:54:16:969'),
	('077.173.243.036', '20260500012', 'materiaalLijst', 'C:\\voorthuis\\templates\\download\\materiaalLijst_20260500012.pdf', '2026-05-01 13:58:01:797'),
	('077.173.243.036', '20260500012', 'wikkelschema', 'C:\\voorthuis\\templates\\download\\wikkelschema_20260500012.pdf', '2026-05-01 13:58:09:876'),
	('077.173.243.036', '20260500013', 'materiaalLijst', 'C:\\voorthuis\\templates\\download\\materiaalLijst_20260500013.pdf', '2026-05-01 13:58:36:376'),
	('077.173.243.036', '20260500013', 'wikkelschema', 'C:\\voorthuis\\templates\\download\\wikkelschema_20260500013.pdf', '2026-05-01 13:58:42:610'),
	('077.173.243.036', '20260500014', 'materiaalLijst', 'C:\\voorthuis\\templates\\download\\materiaalLijst_20260500014.pdf', '2026-05-01 14:00:11:907'),
	('077.173.243.036', '20260500014', 'wikkelschema', 'C:\\voorthuis\\templates\\download\\wikkelschema_20260500014.pdf', '2026-05-01 14:00:19:017'),
	('077.173.243.036', '20260500015', 'materiaalLijst', 'C:\\voorthuis\\templates\\download\\materiaalLijst_20260500015.pdf', '2026-05-01 14:03:09:672'),
	('077.173.243.036', '20260500015', 'wikkelschema', 'C:\\voorthuis\\templates\\download\\wikkelschema_20260500015.pdf', '2026-05-01 14:01:41:017');
/*!40000 ALTER TABLE `tb990_paper_trail` ENABLE KEYS */;

-- Structuur van  view voorthuiscustomersales.vw205_power_trafo_all wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `vw205_power_trafo_all` (
	`ip` VARCHAR(15) NOT NULL COLLATE 'latin1_swedish_ci',
	`trafoNum` VARCHAR(25) NOT NULL COLLATE 'latin1_swedish_ci',
	`secundary` TINYINT(4) NOT NULL,
	`volts` INT(11) NOT NULL,
	`milliAmps` INT(11) NOT NULL,
	`centerTap` TINYINT(4) NOT NULL,
	`tapFiftyVolt` TINYINT(4) NOT NULL,
	`filamentFiveAmps` DECIMAL(4,2) NOT NULL,
	`filamentSixAmps` DECIMAL(4,2) NOT NULL,
	`filamentTwelveAmps` DECIMAL(4,2) NOT NULL,
	`filamentCenterTap` TINYINT(4) NOT NULL,
	`VoltageElectraGrid` INT(11) NULL,
	`FreqElectraGrid` INT(11) NULL
) ENGINE=MyISAM;

-- Structuur van  view voorthuiscustomersales.vw925_customerstats wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `vw925_customerstats` (
	`ip` VARCHAR(15) NOT NULL COLLATE 'latin1_swedish_ci',
	`VoltageElectraGrid` INT(11) NULL,
	`FreqElectraGrid` INT(11) NULL,
	`PermissionStoreAddress` TINYINT(4) NULL,
	`PermissionStorePaymentStats` TINYINT(4) NULL,
	`AgreeShopConditions` TINYINT(4) NULL,
	`ShowInteractiveHelp` TINYINT(4) NULL,
	`email` VARCHAR(70) NULL COLLATE 'latin1_swedish_ci',
	`zipcode` VARCHAR(6) NOT NULL COLLATE 'latin1_swedish_ci',
	`hsNumber` VARCHAR(10) NOT NULL COLLATE 'latin1_swedish_ci',
	`hsNumTvo` VARCHAR(10) NOT NULL COLLATE 'latin1_swedish_ci',
	`Timestamp` VARCHAR(25) NULL COLLATE 'latin1_swedish_ci'
) ENGINE=MyISAM;

-- Structuur van  view voorthuiscustomersales.vw205_power_trafo_all wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `vw205_power_trafo_all`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw205_power_trafo_all` AS SELECT a.ip, a.trafoNum, a.secundary, a.volts, a.milliAmps, a.centerTap, 
		 a.tapFiftyVolt, a.filamentFiveAmps, a.filamentSixAmps, 
		 a.filamentTwelveAmps, a.filamentCenterTap, b.VoltageElectraGrid, 
		 b.FreqElectraGrid 
FROM 
	tb200_power_trafo_config a,
	tb930_grid_settings_per_ip b
WHERE b.ip = a.ip ;

-- Structuur van  view voorthuiscustomersales.vw925_customerstats wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `vw925_customerstats`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw925_customerstats` AS SELECT a.ip, c.VoltageElectraGrid, c.FreqElectraGrid, b.PermissionStoreAddress, 
		 b.PermissionStorePaymentStats, b.AgreeShopConditions, b.ShowInteractiveHelp, 
		 a.email, a.zipcode, a.hsNumber, a.hsNumTvo, a.Timestamp  
FROM tb110_address              a,
	  tb920_customer_settings    b,
	  tb930_grid_settings_per_ip c
WHERE a.ip = b.Ip
AND   a.ip = c.ip ;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
