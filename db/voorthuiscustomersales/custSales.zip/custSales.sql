-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server versie:                10.11.2-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Versie:              11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Databasestructuur van voorthuiscustomersales wordt geschreven
CREATE DATABASE IF NOT EXISTS `voorthuiscustomersales` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `voorthuiscustomersales`;

-- Structuur van  tabel voorthuiscustomersales.tb100_customer wordt geschreven
CREATE TABLE IF NOT EXISTS `tb100_customer` (
  `Id` int(11) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Postcode` varchar(6) DEFAULT NULL,
  `HouseNumber` varchar(7) DEFAULT NULL,
  `HouseNumberTvo` varchar(15) DEFAULT NULL,
  `Street` varchar(50) DEFAULT NULL,
  `City` varchar(50) DEFAULT NULL,
  `Timestamp` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb100_customer: ~0 rows (ongeveer)
/*!40000 ALTER TABLE `tb100_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb100_customer` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb110_address wordt geschreven
CREATE TABLE IF NOT EXISTS `tb110_address` (
  `ip` varchar(15) NOT NULL DEFAULT '',
  `zipcode` varchar(6) NOT NULL DEFAULT '',
  `hsNumber` varchar(10) NOT NULL DEFAULT '',
  `hsNumTvo` varchar(10) NOT NULL DEFAULT '',
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ip`) USING BTREE,
  KEY `tb110_address_idx` (`ip`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb110_address: ~1 rows (ongeveer)
/*!40000 ALTER TABLE `tb110_address` DISABLE KEYS */;
REPLACE INTO `tb110_address` (`ip`, `zipcode`, `hsNumber`, `hsNumTvo`, `Timestamp`) VALUES
	('077.173.243.036', '1831EP', '5', '', '2026-02-25 12:03:08:265');
/*!40000 ALTER TABLE `tb110_address` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb200_power_trafo_config wordt geschreven
CREATE TABLE IF NOT EXISTS `tb200_power_trafo_config` (
  `ip` varchar(15) NOT NULL DEFAULT '0',
  `trafoNum` varchar(25) NOT NULL DEFAULT '0',
  `isClosed` tinyint(4) NOT NULL DEFAULT 0,
  `secundary` tinyint(4) NOT NULL DEFAULT 0,
  `volts` int(11) NOT NULL DEFAULT 0,
  `milliAmps` int(11) NOT NULL DEFAULT 0,
  `centerTap` tinyint(4) NOT NULL DEFAULT 0,
  `tapFiftyVolt` tinyint(4) NOT NULL DEFAULT 0,
  `filamentFiveAmps` decimal(4,2) NOT NULL DEFAULT 0.00,
  `filamentSixAmps` decimal(4,2) NOT NULL DEFAULT 0.00,
  `filamentTwelveAmps` decimal(4,2) NOT NULL DEFAULT 0.00,
  `filamentCenterTap` tinyint(4) NOT NULL DEFAULT 0,
  `timestamp` varchar(25) NOT NULL,
  PRIMARY KEY (`ip`,`trafoNum`) USING BTREE,
  KEY `TrafoNum` (`trafoNum`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb200_power_trafo_config: ~1 rows (ongeveer)
/*!40000 ALTER TABLE `tb200_power_trafo_config` DISABLE KEYS */;
REPLACE INTO `tb200_power_trafo_config` (`ip`, `trafoNum`, `isClosed`, `secundary`, `volts`, `milliAmps`, `centerTap`, `tapFiftyVolt`, `filamentFiveAmps`, `filamentSixAmps`, `filamentTwelveAmps`, `filamentCenterTap`, `timestamp`) VALUES
	('077.173.243.036', 'powertrafo20260200002', 0, 1, 350, 225, 0, 1, 4.00, 2.00, 0.00, 0, '2026-02-21 10:00:55:257');
/*!40000 ALTER TABLE `tb200_power_trafo_config` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb300_shoppingcart wordt geschreven
CREATE TABLE IF NOT EXISTS `tb300_shoppingcart` (
  `ClientId` varchar(36) NOT NULL,
  `GotItems` tinyint(1) DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ClientId`),
  KEY `tb300_shoppingcart_idx` (`ClientId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb300_shoppingcart: ~0 rows (ongeveer)
/*!40000 ALTER TABLE `tb300_shoppingcart` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb300_shoppingcart` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb310_shoppingcartitems wordt geschreven
CREATE TABLE IF NOT EXISTS `tb310_shoppingcartitems` (
  `ClientId` varchar(36) NOT NULL,
  `OrderRow` int(11) NOT NULL DEFAULT 0,
  `Description` varchar(50) NOT NULL,
  `IndexNr` int(11) NOT NULL,
  `itemsOrdered` int(11) DEFAULT NULL,
  `Price` float DEFAULT NULL,
  `totalItemPrice` float DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ClientId`,`OrderRow`) USING BTREE,
  KEY `tb310_shoppingcartitems_idx` (`ClientId`,`OrderRow`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb310_shoppingcartitems: ~0 rows (ongeveer)
/*!40000 ALTER TABLE `tb310_shoppingcartitems` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb310_shoppingcartitems` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb900_session_settings wordt geschreven
CREATE TABLE IF NOT EXISTS `tb900_session_settings` (
  `ip` varchar(15) NOT NULL,
  `SessionActive` tinyint(1) NOT NULL DEFAULT 0,
  `Timestamp` varchar(25) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ip`),
  KEY `Index 1` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb900_session_settings: ~0 rows (ongeveer)
/*!40000 ALTER TABLE `tb900_session_settings` DISABLE KEYS */;
REPLACE INTO `tb900_session_settings` (`ip`, `SessionActive`, `Timestamp`) VALUES
	('077.173.243.036', 1, '2026-02-25 14:39:39:690');
/*!40000 ALTER TABLE `tb900_session_settings` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb910_temp_trafo_settings wordt geschreven
CREATE TABLE IF NOT EXISTS `tb910_temp_trafo_settings` (
  `Ip` varchar(15) NOT NULL,
  `Part` int(11) NOT NULL DEFAULT 0,
  `TrafoType` varchar(50) DEFAULT NULL,
  `CommonValues` varchar(500) DEFAULT NULL,
  `TimeStamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Ip`,`Part`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb910_temp_trafo_settings: ~2 rows (ongeveer)
/*!40000 ALTER TABLE `tb910_temp_trafo_settings` DISABLE KEYS */;
REPLACE INTO `tb910_temp_trafo_settings` (`Ip`, `Part`, `TrafoType`, `CommonValues`, `TimeStamp`) VALUES
	('077.173.243.036', 1, 'powertrafo', '57', '2026-02-21 10:00:40:221'),
	('077.173.243.036', 2, 'powertrafo', 'volts=350-milliAmps=225-filamentSixAmps=2-filamentFiveAmps=4-', '2026-02-21 10:00:55:235');
/*!40000 ALTER TABLE `tb910_temp_trafo_settings` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb920_customer_settings wordt geschreven
CREATE TABLE IF NOT EXISTS `tb920_customer_settings` (
  `Ip` varchar(15) NOT NULL DEFAULT '',
  `PermissionStoreAddress` tinyint(4) DEFAULT NULL,
  `PermissionStorePaymentStats` tinyint(4) DEFAULT NULL,
  `AgreeShopConditions` tinyint(4) DEFAULT NULL,
  `ShowInteractiveHelp` tinyint(4) DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Ip`) USING BTREE,
  KEY `tb920_idx` (`Ip`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb920_customer_settings: ~1 rows (ongeveer)
/*!40000 ALTER TABLE `tb920_customer_settings` DISABLE KEYS */;
REPLACE INTO `tb920_customer_settings` (`Ip`, `PermissionStoreAddress`, `PermissionStorePaymentStats`, `AgreeShopConditions`, `ShowInteractiveHelp`, `Timestamp`) VALUES
	('077.173.243.036', 1, 1, 1, 1, '2026-02-25 12:03:08:258');
/*!40000 ALTER TABLE `tb920_customer_settings` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb930_grid_settings_per_ip wordt geschreven
CREATE TABLE IF NOT EXISTS `tb930_grid_settings_per_ip` (
  `Ip` varchar(15) NOT NULL DEFAULT '0',
  `VoltageElectraGrid` int(11) DEFAULT NULL,
  `FreqElectraGrid` int(11) DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Ip`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb930_grid_settings_per_ip: ~1 rows (ongeveer)
/*!40000 ALTER TABLE `tb930_grid_settings_per_ip` DISABLE KEYS */;
REPLACE INTO `tb930_grid_settings_per_ip` (`Ip`, `VoltageElectraGrid`, `FreqElectraGrid`, `Timestamp`) VALUES
	('077.173.243.036', 230, 50, '2026-02-25 12:03:08:249');
/*!40000 ALTER TABLE `tb930_grid_settings_per_ip` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb990_ip_id_connection wordt geschreven
CREATE TABLE IF NOT EXISTS `tb990_ip_id_connection` (
  `Ip` varchar(15) NOT NULL,
  `Id` int(11) DEFAULT NULL,
  PRIMARY KEY (`Ip`),
  KEY `tb990_idx` (`Id`),
  KEY `Ip` (`Ip`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb990_ip_id_connection: ~0 rows (ongeveer)
/*!40000 ALTER TABLE `tb990_ip_id_connection` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb990_ip_id_connection` ENABLE KEYS */;

-- Structuur van  view voorthuiscustomersales.vw925_customerstats wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `vw925_customerstats` (
	`ip` VARCHAR(15) NOT NULL COLLATE 'latin1_swedish_ci',
	`zipcode` VARCHAR(6) NOT NULL COLLATE 'latin1_swedish_ci',
	`hsNumber` VARCHAR(10) NOT NULL COLLATE 'latin1_swedish_ci',
	`hsNumTvo` VARCHAR(10) NOT NULL COLLATE 'latin1_swedish_ci',
	`Timestamp` VARCHAR(25) NULL COLLATE 'latin1_swedish_ci',
	`PermissionStoreAddress` TINYINT(4) NULL,
	`PermissionStorePaymentStats` TINYINT(4) NULL,
	`AgreeShopConditions` TINYINT(4) NULL,
	`ShowInteractiveHelp` TINYINT(4) NULL,
	`VoltageElectraGrid` INT(11) NULL,
	`FreqElectraGrid` INT(11) NULL
) ENGINE=MyISAM;

-- Structuur van  view voorthuiscustomersales.vw925_customerstats wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `vw925_customerstats`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw925_customerstats` AS SELECT a.*, b.PermissionStoreAddress, b.PermissionStorePaymentStats, b.AgreeShopConditions, b.ShowInteractiveHelp, c.VoltageElectraGrid, c.FreqElectraGrid  FROM 	
					tb110_address              a,
					tb920_customer_settings    b,
					tb930_grid_settings_per_ip c
WHERE a.ip = b.Ip
AND   a.ip = c.ip ;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
